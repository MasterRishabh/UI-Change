// import React from 'react';
// import { shallow } from 'enzyme';

// import UserInput from '../index';

describe('<UserInput />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
