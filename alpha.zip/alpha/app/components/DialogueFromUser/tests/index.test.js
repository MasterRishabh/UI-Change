// import React from 'react';
// import { shallow } from 'enzyme';

// import DialogueFromUser from '../index';

describe('<DialogueFromUser />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
