// import React from 'react';
// import { shallow } from 'enzyme';

// import BotHeader from '../index';

describe('<BotHeader />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
