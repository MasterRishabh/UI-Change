// import React from 'react';
// import { shallow } from 'enzyme';

// import DialogueFromBot from '../index';

describe('<DialogueFromBot />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
