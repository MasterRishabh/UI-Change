export const TEXT = 'text';

export const TRANSFORMED_TEXT = 'transformedText';

export const LINK = 'link';

export const MEDIA = 'media';
