const recommendationBags = [
	{
		name: "rickAndMorty",
		defaultValue: 0,
		goToBubbleId: "rickAndMorty",
	},
	{
		name: "shroedingersCat",
		defaultValue: 0,
		goToBubbleId: "shroedingersCat",
	},
	{
		name: "recursion",
		defaultValue: 0,
		goToBubbleId: "recursion",
	},
]

export default recommendationBags;