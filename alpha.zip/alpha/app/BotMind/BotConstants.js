export const name = 'Alpha'
export const position = 'Virtual Assistant'
export const company = 'Icalia Labs'