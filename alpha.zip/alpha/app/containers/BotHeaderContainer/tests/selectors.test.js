// import { fromJS } from 'immutable';
// import { makeSelectBotHeaderContainerDomain } from '../selectors';

// const selector = makeSelectBotHeaderContainerDomain();

describe('makeSelectBotHeaderContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
