// import React from 'react';
// import { shallow } from 'enzyme';

// import { BotHeaderContainer } from '../index';

describe('<BotHeaderContainer />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
