// import { fromJS } from 'immutable';
// import { makeSelectBotContainerDomain } from '../selectors';

// const selector = makeSelectBotContainerDomain();

describe('makeSelectBotContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
