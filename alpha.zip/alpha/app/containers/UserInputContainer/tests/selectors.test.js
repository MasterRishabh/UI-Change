// import { fromJS } from 'immutable';
// import { makeSelectUserInputContainerDomain } from '../selectors';

// const selector = makeSelectUserInputContainerDomain();

describe('makeSelectUserInputContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
